.. gobnilp documentation master file, created by
   sphinx-quickstart on Thu Jun 13 17:28:51 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to gobnilp's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. automodule:: gobnilp
   :members:
   :special-members:
   :exclude-members: __weakref__
.. autoclass:: discrete_scoring.BDeuScoresGenerator
   :members:
   :special-members:
   :exclude-members: __weakref__
.. autoclass:: continuous_scoring.BGe
   :members:
   :special-members:
   :exclude-members: __weakref__


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
